---
title: Qbot Config Extractor
description: >-
  Python script to extract and parse Qbot configuration.
template: tools.html
tags:
  - Qbot
  - Tools
authors:
  - cyril-t-f
  - dcode
---

## Getting Started

### Usage

```commandline
$ qbot-config-extractor
usage: Qbot Configuration Extractor [-h] (-f FILE | -d DIRECTORY)

options:
  -h, --help            show this help message and exit
  -f FILE, --file FILE  Qbot sample path
  -d DIRECTORY, --directory DIRECTORY
                        Qbot samples folder
```

### Example

```commandline
qbot-config-extractor -f ~/Downloads/c2ba065654f13612ae63bca7f972ea91c6fe97291caeaaa3a28a180fb1912b3a
```

![Example output](./statics/example.png)

### Docker

The recommended and easiest way to get going is to use Docker. From the directory this README is in,
you can build a local container.

```bash
docker build . -t qbot-config-extractor
```

Then we run the container with the **-v** flag to map a host directory to the docker container directory

```bash
docker run -ti --rm -v $(pwd)/data:/data qbot-config-extractor:latest --help
```

### Running it Locally

As mentioned above, Docker is the recommended approach to running this project, however you can also run this locally.
This project uses [Poetry](https://python-poetry.org/) to manage dependencies, testing, and metadata. If you have Poetry
 installed already, from this directory, you can simply run the following commands to run the tool. This will setup a
 virtual environment, install the dependencies, activate the virtual environment, and run the console script.

```bash
poetry lock
poetry install
poetry shell
qbot-config-extractor --help
```

Once that works, you can do the same sort of things as mentioned in the Docker instructions above.
