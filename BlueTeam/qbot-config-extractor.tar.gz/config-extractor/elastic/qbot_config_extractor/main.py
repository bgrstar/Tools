# coding: utf-8
import argparse
import functools
import os
import sys

from .core import common, obfuscated_strings, parsers, rsrc


def try_decipher_resource(resource: bytes, keys: list[bytes]) -> tuple[bytes, bytes]:
    for x in keys:
        try:
            return x, rsrc.decipher_resource(resource, x)
        except rsrc.MismatchingHashes:
            continue
    else:
        raise RuntimeError("Failed to decipher resource.")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser("Qbot Configuration Extractor")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-f", "--file", help="Qbot sample path")
    group.add_argument("-d", "--directory", help="Qbot samples folder")
    return parser.parse_args()


def list_files(path: str) -> list[str]:
    return [x.path for x in os.scandir(path) if x.is_file()]


def main() -> None:
    args = parse_arguments()
    files = list()
    if args.file is not None:
        files.append(args.file)
    elif args.directory is not None:
        files += list_files(args.directory)
    else:
        raise RuntimeError("Both file and directory arguments are missing.")
    for file in files:
        deobfuscated_strings = obfuscated_strings.deobfuscate_strings(file)

        print("=== Strings ===")
        for x in deobfuscated_strings:
            print(str(x))

        func = functools.partial(
            try_decipher_resource,
            keys=[
                x[:-1]
                for x in functools.reduce(
                    common.merge_dictionary_values,
                    (x.strings for x in deobfuscated_strings),
                    list(),
                )
            ],
        )

        for i, x in enumerate(map(func, rsrc.extract_resources(file))):
            print("=== RESOURCE {} ===".format(i))
            print("Key: {}".format(x[0]))
            print("Type: {}".format(parsers.DataType.detect_data_type(x[1])))
            for y in parsers.parse_data(x[1]):
                print(y)
            print()


if __name__ == "__main__":
    version = sys.version_info
    if version.major >= 3 and version.minor >= 10:
        main()
    else:
        raise RuntimeError("Invalid Python version, version >= 3.10 is required.")
