# coding: utf-8

import struct
from importlib import resources

import lief
import unicorn
import yara
from smda.common.CodeXref import CodeXref
from smda.common.SmdaFunction import SmdaFunction

from . import common

KEY_SIZE = 0x5A
PACKAGE_NAME = "elastic.qbot_config_extractor"
RULE_FILE = "rule.yar"


class DeobfuscatedStrings:
    def __init__(
        self, blob: bytes, key: bytes, blob_address: int = 0, key_address: int = 0
    ):
        self.__blob = blob
        self.__key = key
        self.__blob_address = blob_address
        self.__key_address = key_address
        self.__strings: dict[int, bytes] = dict()
        self.__decipher_strings()

    def __decipher_strings(self) -> None:
        current_index = 0
        current_string = list()
        for i in range(len(self.__blob)):
            current_string.append(self.__blob[i] ^ self.__key[i % len(self.__key)])
            if self.__blob[i] == self.__key[i % len(self.__key)]:
                self.__strings[current_index] = bytes(current_string)
                current_string = list()
                current_index = i + 1

    def __str__(self) -> str:
        result = "# Blob address: 0x{:x}\n".format(self.__blob_address)
        result += "# Key address: 0x{:x}\n".format(self.__key_address)
        for k, v in self.__strings.items():
            result += "[0x{:x}]: {}\n".format(k, v.decode("utf-8"))
        return result

    @property
    def strings(self) -> dict[int, bytes]:
        return self.__strings.copy()


def __find_function(file_path: str) -> SmdaFunction:

    rule_path = resources.path(PACKAGE_NAME, RULE_FILE)
    rule = yara.compile(filepath=str(rule_path))
    pe = common.parse_pe(file_path)
    return common.function_from_address(
        common.disassemble(file_path),
        pe.imagebase
        + pe.offset_to_virtual_address(rule.match(file_path)[0].strings[0][0]),
    )


def __extract_parameters(pe: lief.PE.Binary, target: CodeXref) -> tuple[int, int, int]:
    emu = common.new_emulator()
    emu.mem_map(pe.imagebase, common.EMU_MEM_SIZE)
    emu.mem_write(
        target.from_function.offset,
        bytes(
            pe.get_content_from_virtual_address(
                target.from_function.offset, target.from_instruction.offset - target.from_function.offset
            )
        ),
    )
    emu.emu_start(target.from_function.offset, target.from_instruction.offset)

    blob_address = emu.reg_read(unicorn.x86_const.UC_X86_REG_ECX)
    blob_size = emu.reg_read(unicorn.x86_const.UC_X86_REG_EDX)
    key_address = struct.unpack(
        "I", emu.mem_read(emu.reg_read(unicorn.x86_const.UC_X86_REG_ESP), 4)
    )[0]

    return blob_address, blob_size, key_address


def deobfuscate_strings(file_path: str) -> list[DeobfuscatedStrings]:
    function = __find_function(file_path)
    pe = common.parse_pe(file_path)
    result = list()
    for target in function.getCodeInrefs():
        blob_address, blob_size, key_address = __extract_parameters(pe, target)
        result.append(
            DeobfuscatedStrings(
                pe.get_content_from_virtual_address(blob_address, blob_size),
                pe.get_content_from_virtual_address(key_address, KEY_SIZE),
                blob_address,
                key_address,
            )
        )
    return result
