# coding: utf-8

from __future__ import annotations

from Crypto.Cipher import ARC4
from Crypto.Hash import SHA1

from . import common


class MismatchingHashes(Exception):
    pass


def __decipher_data(data: bytes, key: bytes) -> tuple[bytes, bytes]:
    data = ARC4.ARC4Cipher(SHA1.SHA1Hash(key).digest()).decrypt(data)
    return data[20:], data[:20]


def __verify_hash(data: bytes, expected_hash: bytes) -> bool:
    return SHA1.SHA1Hash(data).digest() == expected_hash


def decipher_resource(resource: bytes, key: bytes) -> bytes:
    deciphered_rsrc, expected_hash = __decipher_data(resource[20:], resource[:20])
    if not __verify_hash(deciphered_rsrc, expected_hash):
        deciphered_rsrc, expected_hash = __decipher_data(resource, key)
        if not __verify_hash(deciphered_rsrc, expected_hash):
            raise MismatchingHashes("Failed to decipher resource.")
    return deciphered_rsrc


def extract_resources(file_path: str) -> list[bytes]:
    result = list()
    pe = common.parse_pe(file_path)
    for x in pe.resources.childs:
        for y in x.childs:
            result.append(bytes(y.childs[0].content))
    return result
