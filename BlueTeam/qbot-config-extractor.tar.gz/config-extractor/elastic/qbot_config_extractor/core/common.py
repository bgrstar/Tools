# coding: utf-8

import itertools
from typing import Any, TypeVar

import lief
import unicorn
from smda import Disassembler
from smda.common.CodeXref import CodeXref
from smda.common.SmdaFunction import SmdaFunction
from smda.common.SmdaReport import SmdaReport

V = TypeVar("V")

EMU_MEM_SIZE = 2 * 1024 * 1024
EMU_STACK_ADDRESS = 0x20000
PE: lief.PE.Binary | None = None


def merge_dictionary_values(acc: list[V], x: dict[Any, V]) -> list[V]:
    acc += x.values()
    return acc


def parse_pe(file_path: str) -> lief.PE.Binary:
    global PE
    if not PE:
        with open(file_path, "rb") as f:
            PE = lief.parse(f.read())
    return PE


def new_emulator() -> unicorn.Uc:
    emu = unicorn.Uc(unicorn.UC_ARCH_X86, unicorn.UC_MODE_32)
    emu.mem_map(EMU_STACK_ADDRESS, EMU_MEM_SIZE)
    emu.reg_write(
        unicorn.x86_const.UC_X86_REG_ESP, EMU_STACK_ADDRESS + (EMU_MEM_SIZE // 2)
    )
    return emu


def disassemble(file_path: str) -> SmdaReport:
    return Disassembler.Disassembler().disassembleFile(file_path)


def function_from_address(disassembly: SmdaReport, address: int) -> SmdaFunction:
    for _ in itertools.count(100):
        if function := disassembly.getFunction(address):
            return function
        address -= 1
    else:
        raise RuntimeError("Failed to find function start: 0{:x}".format(address))


def get_function_xrefs(disassembly: SmdaReport, address: int) -> list[CodeXref]:
    function = function_from_address(disassembly, address)
    return list(function.getCodeInrefs())
