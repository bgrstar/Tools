# coding: utf-8
from __future__ import annotations

import enum
import socket
import string
import struct


class DataType(enum.Enum):
    CONFIGURATION = enum.auto()
    DOMAINS = enum.auto()
    UNKNOWN = enum.auto()

    @staticmethod
    def __is_data_printable(data: bytes) -> bool:
        printable = bytes(string.printable, "utf-8")
        return all((x in printable for x in data))

    @staticmethod
    def detect_data_type(data: bytes) -> DataType:
        if not DataType.__is_data_printable(data) and len(data) % 7 == 0:
            return DataType.DOMAINS
        elif b"\r\n" in data and b"=" in data:
            return DataType.CONFIGURATION
        else:
            return DataType.UNKNOWN


def parse_configuration(data: bytes) -> list[str]:
    result = list()
    for x in (x for x in data.split(b"\r\n") if x):
        result.append(x.decode("utf-8"))
    return result


def parse_domains(data: bytes) -> list[str]:
    result = list()
    for i in range(0, len(data), 7):
        result.append(
            "{}:{}".format(
                socket.inet_ntoa(data[i + 1 : i + 5]),
                struct.unpack(">H", data[i + 5 : i + 7])[0],
            )
        )
    return result


def parse_data(data: bytes) -> list[str]:
    match DataType.detect_data_type(data):
        case DataType.CONFIGURATION:
            return parse_configuration(data)
        case DataType.DOMAINS:
            return parse_domains(data)
        case _:  # Handle default case, but should only be DataType.UNKNOWN
            raise RuntimeError("Unknown data type!")
