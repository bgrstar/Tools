from importlib.metadata import version


def test_version() -> None:
    assert version("elastic.qbot_config_extractor") == "0.1.0"
